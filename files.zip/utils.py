import shutil

def save_image(src, dst):
    shutil.copy(src, dst)